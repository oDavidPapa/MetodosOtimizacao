#include <iostream>
#include <stdio.h>
#include <memory.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>

#include "prc.h"

#define MAX(X, Y) (((X) > (Y)) ? (X) : (Y))

// PESOS PARA PENALIZAÇÃO DA FO

int OM1 = 100;
int OM2 = 100;
int OM3 = 50;
int OM4 = 1000; 
int OM5 = 1000; 

int main(int argc, char *argv[])
{
    //srand(time(NULL));

    //Variaveis:

    char aux[50];
    Solucao solucao;
    Solucao clone;
    Solucao solucaoExterna;
    double tempo;
    clock_t h;

    //Ler dos dados do Problema:

    strcpy(aux, "lotes20.txt");
    lerDadosLote(aux);

    strcpy(aux, "culturas.txt");
    lerDadosCultura(aux);

    //imprimeDados();  // Mostrar os Dados lidos inicialmente

    // Pré Operacoes:
    calcularCicloCulturas();
    ordenarDados();

    //Os experimentos devem ser conduzidos nesta ordem:
    solucionar(solucao);
    verificarSolucao(solucao);
    h = clock();
    for(int i = 0; i < 1000; i++)
    calcularFO(solucao);

    h = clock() - h;
    tempo = (double)h / CLOCKS_PER_SEC;
    printf("\n\n: %.5f\n", tempo);
    escreverSolucao(solucao);
    escreverSolucaoArquivo(solucao); // FO, Matriz Solucao, Pousio, Lotes Adjacentes

    //Medindo o TEMPO:
    // # code ...

    // Em caso de leitura de uma solução externa qualquer:

    /*
    strcpy(aux, "solucao.txt"); // Auxiliar parar Ler Solução Externa
    solucaoExterna = lerSolucao(aux, 9, 12);
    verificarSolucao(solucaoExterna);
    calcularFO(solucaoExterna);
    escreverSolucao(solucaoExterna);
    escreverSolucaoArquivo(solucaoExterna);

    */
}

// Ler dados do LOTE:

void lerDadosLote(const char *arq)
{
    FILE *f = fopen(arq, "r");
    fscanf(f, "%d ", &quantidadeLotes);

    for (int i = 0; i < quantidadeLotes; i++)
        fscanf(f, "%f ", &vetAreaLotes[i]);

    for (int i = 0; i < quantidadeLotes; i++)
    {
        fscanf(f, "%d", &vetQtdVizinhos[i]);
        for (int j = 0; j < vetQtdVizinhos[i]; j++)
        {
            fscanf(f, "%d ", &matLotesVizinhos[i][j]);
        }
    }

    fclose(f);
}
// Ler dados das CULTURAS:

void lerDadosCultura(const char *arq)
{
    FILE *f = fopen(arq, "r");
    fscanf(f, "%d %d \n", &pousio, &adubacaoVerde);
    for (int i = 0; i < MAX_CULTURA; i++)
    {
        fscanf(f, "%d %d %d %d %d %d", &vetCulturas[i].cultura, &vetCulturas[i].familia, &vetCulturas[i].inicioPlantio,
               &vetCulturas[i].fimPlantio, &vetCulturas[i].ciclo, &vetCulturas[i].lucratividade);
    }

    fclose(f);
}

// Lendo uma solucão qualquer
Solucao lerSolucao(const char *arq, int L, int P)
{
    Solucao s;
    FILE *f = fopen(arq, "r");
    fscanf(f, "%f", &s.funcObj);
    for (int i = 0; i < L; i++)
    {
        for (int j = 0; j < P; j++)
        {
            fscanf(f, "%d", &s.matSolucao[i][j]);
        }
    }
    fclose(f);

    return s;
}

// Imprimir Dados LOTES E CULTURAS:

void imprimeDados()
{
    printf("%d \n", quantidadeLotes);

    for (int i = 0; i < quantidadeLotes; i++)
        printf("%.2f ", vetAreaLotes[i]);
    printf("\n");

    printf("%d  %d", pousio, adubacaoVerde);
    printf("\n");
    for (int i = 0; i < MAX_CULTURA; i++)
    {
        printf("%d %d %d %d %d %d \n", i, vetCulturas[i].cultura, vetCulturas[i].familia, vetCulturas[i].inicioPlantio,
               vetCulturas[i].fimPlantio, vetCulturas[i].ciclo, vetCulturas[i].lucratividade);
    }

    for (int i = 0; i < quantidadeLotes; i++)
    {
        printf("%d\n", vetQtdVizinhos[i]);
        for (int j = 0; j < vetQtdVizinhos[i]; j++)
        {

            printf("%d  ", matLotesVizinhos[i][j]);
        }
        printf("\n");
    }
}

// Calcular Ciclo das Culturas:

void calcularCicloCulturas()
{
    for (int i = 0; i < MAX_CULTURA; i++)
        vetCicloCultura[i] = ceil(vetCulturas[i].ciclo / 30.0);
}

// Clonar uma solucao:

void clonarSolucao(Solucao &solucao, Solucao &clone)
{
    memcpy(&clone, &solucao, sizeof(solucao));
}

// Solução Construtiva:

void solucionar(Solucao &solucao)
{
    int periodo, cultura, ciclo, opcao;
    int adbVerde;

    memset(&solucao, 0, sizeof(solucao));

    for (int i = 0; i < quantidadeLotes; i++)
    {
        for (int j = 0; j < PERIODO; j++)
        {
            if (solucao.matSolucao[i][j] == 0)
            {
                solucao.matSolucao[i][j] = 28;
            }
        }
    }

    for (int i = 0; i < quantidadeLotes; i++)
    {
        // Seleciona entre as 3 adubações verde possíveis.

        adbVerde = MAX_CULTURA - ((rand() % 3) + 1);

        switch (adbVerde)
        {

        case 25:
            // Neste caso não foi necessário realizar um tratamento para 12 ou 24 meses
            periodo = PERIODO - ((rand() % 4) + 7);

            solucao.matSolucao[i][periodo] = 25;
            solucao.matSolucao[i][periodo + 1] = 25;
            solucao.matSolucao[i][periodo + 2] = 25;
            solucao.matSolucao[i][periodo + 3] = 25;
            solucao.matSolucao[i][periodo + 4] = 25;
            break;
        case 26:
            // Neste caso em particular precisei fazer a divisão entre 12 e 24 MESES.
            if (PERIODO == 12)
            {
                periodo = PERIODO - ((rand() % 4) + 1);

                switch (periodo)
                {
                case 8:
                    solucao.matSolucao[i][periodo] = 26;
                    solucao.matSolucao[i][periodo + 1] = 26;
                    solucao.matSolucao[i][periodo + 2] = 26;
                    break;

                case 9:
                    solucao.matSolucao[i][periodo] = 26;
                    solucao.matSolucao[i][periodo + 1] = 26;
                    solucao.matSolucao[i][periodo + 2] = 26;
                    break;

                case 10:
                    solucao.matSolucao[i][periodo] = 26;
                    solucao.matSolucao[i][periodo + 1] = 26;
                    solucao.matSolucao[i][periodo - periodo] = 26;
                    break;

                case 11:
                    solucao.matSolucao[i][periodo] = 26;
                    solucao.matSolucao[i][periodo - periodo] = 26;
                    solucao.matSolucao[i][(periodo + 1) - periodo] = 26;
                    break;

                default:
                    break;
                }
            }

            if (PERIODO == 24)
            {
                opcao = rand() % 2;
                //int opcao = 0;
                if (opcao == 1)
                {
                    periodo = 12 - ((rand() % 4) + 1);

                    solucao.matSolucao[i][periodo] = 26;
                    solucao.matSolucao[i][periodo + 1] = 26;
                    solucao.matSolucao[i][periodo + 2] = 26;
                    break;
                }
                else
                {
                    periodo = PERIODO - ((rand() % 4) + 1);
                    switch (periodo)
                    {
                    case 20:
                        solucao.matSolucao[i][periodo] = 26;
                        solucao.matSolucao[i][periodo + 1] = 26;
                        solucao.matSolucao[i][periodo + 2] = 26;
                        break;

                    case 21:
                        solucao.matSolucao[i][periodo] = 26;
                        solucao.matSolucao[i][periodo + 1] = 26;
                        solucao.matSolucao[i][periodo + 2] = 26;
                        break;

                    case 22:
                        solucao.matSolucao[i][periodo] = 26;
                        solucao.matSolucao[i][periodo + 1] = 26;
                        solucao.matSolucao[i][periodo - periodo] = 26;
                        break;

                    case 23:
                        solucao.matSolucao[i][periodo] = 26;
                        solucao.matSolucao[i][periodo - periodo] = 26;
                        solucao.matSolucao[i][(periodo + 1) - periodo] = 26;
                        break;

                    default:
                        break;
                    }
                }

            case 27:
                // Aqui novamente o método de colocar a adubação verde é diferente se considerarmos 24 ou 12 meses
                if (PERIODO == 12)
                {
                    periodo = PERIODO - ((rand() % 5) + 1);

                    switch (periodo)
                    {
                    case 8:
                        solucao.matSolucao[i][periodo] = 27;
                        solucao.matSolucao[i][periodo + 1] = 27;
                        solucao.matSolucao[i][periodo + 2] = 27;
                        solucao.matSolucao[i][periodo + 3] = 27;
                        break;

                    case 9:
                        solucao.matSolucao[i][periodo] = 27;
                        solucao.matSolucao[i][periodo + 1] = 27;
                        solucao.matSolucao[i][periodo + 2] = 27;
                        solucao.matSolucao[i][0] = 27;
                        break;

                    case 10:
                        solucao.matSolucao[i][periodo] = 27;
                        solucao.matSolucao[i][periodo + 1] = 27;
                        solucao.matSolucao[i][0] = 27;
                        solucao.matSolucao[i][1] = 27;
                        break;

                    case 11:
                        solucao.matSolucao[i][periodo] = 27;
                        solucao.matSolucao[i][0] = 27;
                        solucao.matSolucao[i][1] = 27;
                        solucao.matSolucao[i][2] = 27;
                        break;

                    case 7:
                        solucao.matSolucao[i][0] = 27;
                        solucao.matSolucao[i][1] = 27;
                        solucao.matSolucao[i][2] = 27;
                        solucao.matSolucao[i][3] = 27;
                        break;

                    default:
                        break;
                    }
                }
                if (PERIODO == 24)
                {
                    int opcao;
                    opcao = rand() % 2;

                    if (opcao == 0)
                    {
                        periodo = 12 - ((rand() % 5) + 1);

                        solucao.matSolucao[i][periodo] = 27;
                        solucao.matSolucao[i][periodo + 1] = 27;
                        solucao.matSolucao[i][periodo + 2] = 27;
                        solucao.matSolucao[i][periodo + 3] = 27;
                    }
                    else
                    {

                        if (PERIODO == 24)
                        {
                            periodo = PERIODO - ((rand() % 5));

                            switch (periodo)
                            {
                            case 20:
                                solucao.matSolucao[i][periodo] = 27;
                                solucao.matSolucao[i][periodo + 1] = 27;
                                solucao.matSolucao[i][periodo + 2] = 27;
                                solucao.matSolucao[i][periodo + 3] = 27;
                                break;

                            case 21:
                                solucao.matSolucao[i][periodo] = 27;
                                solucao.matSolucao[i][periodo + 1] = 27;
                                solucao.matSolucao[i][periodo + 2] = 27;
                                solucao.matSolucao[i][periodo - periodo] = 27;
                                break;

                            case 22:
                                solucao.matSolucao[i][periodo] = 27;
                                solucao.matSolucao[i][periodo + 1] = 27;
                                solucao.matSolucao[i][periodo - periodo] = 27;
                                solucao.matSolucao[i][(periodo - periodo) + 1] = 27;
                                break;

                            case 23:
                                solucao.matSolucao[i][periodo] = 27;
                                solucao.matSolucao[i][0] = 27;
                                solucao.matSolucao[i][1] = 27;
                                solucao.matSolucao[i][2] = 27;
                                break;

                            case 24:
                                periodo = 0;
                                solucao.matSolucao[i][periodo] = 27;
                                solucao.matSolucao[i][periodo + 1] = 27;
                                solucao.matSolucao[i][periodo + 2] = 27;
                                solucao.matSolucao[i][periodo + 3] = 27;
                                break;

                            default:
                                break;
                            }
                        }
                    }
                }

            default:
                break;
            }
        }
    }

    //for (int i = 0; i < 2; i++); Avaliar se é melhor rodar duas vezes ou uma só

    int mes = 0;
    int index = 0, inicio, fim;

    // Colocando as culturas, respeitando o seu ciclo e seu período de Plantio;

    for (int i = 0; i < quantidadeLotes; i++)
    {
        mes = 0;
        while (mes < PERIODO)
        {
            if (solucao.matSolucao[i][mes] == 28)
            {
                int opcao;
                // Random para selecionar as culturas.
                // Sendo que nas Opções 0 e 1, ele seleciona aleatorimaente dentre as melhores 9 culturas;
                // levando em consideração a lucratividade / ciclo;
                // Já na opção 2, ele seleciona aleatoriamente dentre as 28 culturas disponíveis.

                opcao = rand() % 3; // voltar com o 3 aqui!

                if (opcao == 1)
                    index = rand() % MAX_CULTURA;
                else
                    index = rand() % 9; // 5 bom resultado
                // Por enquanto estou testando apenas com as 9 melhores culturas para ver se dá alguma viável

                cultura = vetCulturas[vetIndiceCulturasOrdenadas[index]].cultura;
                ciclo = vetCicloCultura[vetIndiceCulturasOrdenadas[index]];
                inicio = vetCulturas[vetIndiceCulturasOrdenadas[index]].inicioPlantio - 1;
                fim = vetCulturas[vetIndiceCulturasOrdenadas[index]].fimPlantio - 1;

                // Uma vez selecionada a cultura, ele verifica se a mesma está apta a ser plantada no MES vigente, respeitando seu inicio e fim de cultivo.
                if (mes >= inicio && mes <= fim)
                {
                    // Enquanto não terminar o ciclo, ele coloca a cultura selecionada
                    // Porém, somente nos espaços onde existe primeiramente "Pousio";
                    // Sendo assim, pode ocorrer uma quebra de ciclo, caso haja alguma adubação verde no caminho

                    int nCabe = 0;
                    int cicloAux = ciclo;
                    int mesAux = mes;

                    // Verificando se existe espaço para plantar a Cultura respeitando o Ciclo;
                    // Utilizando uma variável "nCabe", toda vez que um ciclo é quebrado, é incrementado um valor a esta variável!

                    while (ciclo != 0)
                    {
                        if (solucao.matSolucao[i][mes] == 28)
                        {
                            ciclo--;
                            mes++;
                        }
                        else
                        {
                            ciclo--;
                            mes++;
                            nCabe++;
                        }
                    }
                    // Se nCabe não sofreu nenhum incremento, significa que aquela cultura certamente caberá naquele espaço, respeitando o seu ciclo de maneira correta!

                    if (nCabe == 0)
                    {
                        while (cicloAux != 0)
                        {
                            solucao.matSolucao[i][mesAux] = cultura;
                            cicloAux--;
                            mesAux++;
                        }
                    }
                }
                else
                {
                    mes++;
                }
            }
            else
            {
                mes++;
            }
        }
    }
}

// Escrever a solução no Terminal:

void escreverSolucao(Solucao &solucao)
{
    printf("FO: %.2f\n", solucao.funcObj);
    for (int i = 0; i < quantidadeLotes; i++)
    {
        for (int j = 0; j < PERIODO; j++)
        {
            printf(" [%d] ", solucao.matSolucao[i][j]);
        }
        printf("\n");
    }
    printf("\n ---- \n");

    printf("Quantidade de Conflitos Adjacentes por Lotes:\n");
    for (int i = 0; i < quantidadeLotes; i++)
        printf("Lote %d: %d\n", i, vetCultAdjacente[i]);

    printf("TOTAL: %d\n\n", pa);

    printf("Lucratividade por Lotes:\n");

    for (int i = 0; i < quantidadeLotes; i++)
    {
        printf("Lote %d: %.2f\n", i, vetLucratividadeLote[i]);
    }
    printf("TOTAL: %.2f\n\n", lt);

    printf("Pousio por Lote:\n");
    for (int i = 0; i < quantidadeLotes; i++)
    {
        printf("Lote %d: %d\n", i, vetPousioLote[i]);
    }
    printf("TOTAL: %d\n", po);
}

// Escrever a Solucao em Arquivo Externo: ("solucaoDetalhe.txt")

void escreverSolucaoArquivo(Solucao &solucao)
{
    FILE *f = fopen("solucaoDetalhe.txt", "w");

    // Funcao Objetiva
    fprintf(f, "%.2f\n", solucao.funcObj);

    // Lotes x Periodos com Culturas da rotação
    for (int i = 0; i < quantidadeLotes; i++)
    {
        for (int j = 0; j < PERIODO; j++)
        {
            fprintf(f, "%d  ", solucao.matSolucao[i][j]);
        }
        fprintf(f, "\n");
    }

    fprintf(f, "\n");

    // Quantidade Total de Pousios da Rotação:
    fprintf(f, "%d \n", po);

    // Quantidade de Pousios por Lote:
    for (int i = 0; i < quantidadeLotes; i++)
    {
        fprintf(f, "%d  ", vetPousioLote[i]);
    }

    fprintf(f, "\n");

    // Quantidade TOTAL de Familia com Conflitos em Lotes Adjacente:
    fprintf(f, "%d \n", pa);

    // Quantidade de Familia com Conflitos POR LOTE:
    for (int i = 0; i < quantidadeLotes; i++)
    {
        fprintf(f, "%d  ", vetCultAdjacente[i]);
    }
    fprintf(f, "\n");

    // Lucratividade Total da Rotação:
    fprintf(f, "%.2f \n", lt);

    // Lucratividade Por Lote:
    for (int i = 0; i < quantidadeLotes; i++)
    {
        fprintf(f, "%.2f  ", vetLucratividadeLote[i]);
    }

    fclose(f);
}

// Ordenacao dos Dados: (Lucratividade / Ciclo) ;

void ordenarDados()
{
    int flag, auxiliar;

    for (int i = 0; i < MAX_CULTURA; i++)
        vetIndiceCulturasOrdenadas[i] = i;

    flag = 1;

    while (flag)
    {
        flag = 0;
        for (int i = 0; i < MAX_CULTURA - 1; i++)
        {
            if ((double)(vetCulturas[vetIndiceCulturasOrdenadas[i]].lucratividade / vetCicloCultura[vetIndiceCulturasOrdenadas[i]]) < (double)(vetCulturas[vetIndiceCulturasOrdenadas[i + 1]].lucratividade / vetCicloCultura[vetIndiceCulturasOrdenadas[i + 1]]))
            {
                flag = 1;
                auxiliar = vetIndiceCulturasOrdenadas[i];
                vetIndiceCulturasOrdenadas[i] = vetIndiceCulturasOrdenadas[i + 1];
                vetIndiceCulturasOrdenadas[i + 1] = auxiliar;
            }
        }
    }

    // for (int i = 0; i < MAX_CULTURA; i++);

    // printf("%d , ", vetCulturas[vetIndiceCulturasOrdenadas[i]]);
}

// Verificando a solucao gerada:

void verificarSolucao(Solucao &solucao)
{
    // Verificando os Lotes adjacentes:

    for (int i = 0; i < quantidadeLotes; i++)
    {
        //printf("\nVizinhos: %d\n", vetQtdVizinhos[i]);
        int qtdVizinhos = vetQtdVizinhos[i];

        for (int q = 0; q < qtdVizinhos; q++)
        {
            int vizinho = matLotesVizinhos[i][q] - 1;
            // printf("%d", matLotesVizinhos[i][q]);

            for (int j = 0; j < PERIODO; j++)
            {
                if (vetCulturas[solucao.matSolucao[i][j] - 1].familia == vetCulturas[solucao.matSolucao[vizinho][j] - 1].familia && solucao.matSolucao[i][j] != 28)
                {
                    // Neste printf ele detalha os Lotes com familia em conflito, a cultura e o periodo;
                    // Bastando Tirar o comentário do Printf;

                    //printf("Conflito no Lote %d com o Lote %d, nas Culturas: %d / %d, no Periodo: %d\n", i, vizinho, solucao.matSolucao[i][j], solucao.matSolucao[vizinho][j], j);

                    vetCultAdjacente[i] += 1;
                    pa++;
                }
                else
                {
                    // Neste printf ele lista as adjacências que estão 'OK', sem conflito:

                    //printf("NAO ha conflito: Lote i: %d - Lote v: %d, %d / %d\n", i, vizinho, solucao.matSolucao[i][j], solucao.matSolucao[vizinho][j]);
                }
            }
        }
    }

    // Verificando os Pousios por Lote:

    for (int i = 0; i < quantidadeLotes; i++)
    {
        for (int j = 0; j < PERIODO; j++)
        {
            if (solucao.matSolucao[i][j] == 28)
            {
                vetPousioLote[i] += 1;
                po++;
            }
        }
    }

    // Verificar a Adubacao Verde por Lote:
    for (int i = 0; i < quantidadeLotes; i++)
    {
        for (int j = 0; j < PERIODO; j++)
        {
        }
    }

    // Verificar o Ciclo por Lote:
}

// Calculando a FO;

void calcularFO(Solucao &solucao)
{
    solucao.funcObj = 0;

    for (int i = 0; i < quantidadeLotes; i++)
    {
        for (int j = 0; j < PERIODO; j++)
        {
            if (solucao.matSolucao[i][j] != 28 && solucao.matSolucao[i][j] != 25 &&
                solucao.matSolucao[i][j] != 26 && solucao.matSolucao[i][j] != 27)
            {
                int cultura = solucao.matSolucao[i][j];
                int ciclo = vetCicloCultura[solucao.matSolucao[i][j] - 1];
                int completo = 0;
                int cont = 0;
                int cicloAux = ciclo;
                int aux = 0;
                while (ciclo != 0)
                {
                    if (solucao.matSolucao[i][j + cont] == cultura)
                    {
                        completo++;
                        ciclo--;
                        cont++;
                    }
                    else if ((j + cont) % PERIODO == 0)
                    {
                        int aux = 0;
                        while (ciclo != 0)
                        {
                            if (solucao.matSolucao[i][aux] == cultura)
                            {
                                printf("cultura %d\n", cultura);
                                completo++;
                                ciclo--;
                                cont++;
                                aux++;
                            }
                            else
                            {
                                ciclo--;
                                cont++;
                            }
                        }
                    }
                    else
                    {
                        ciclo--;
                        cont++;
                    }

                    // Só soma na lucratividade SE o ciclo da plantação estiver COMPLETO

                    if (completo == cicloAux)
                    {
                        // Guardando a Lucratividade por Lote:
                        vetLucratividadeLote[i] += vetCulturas[cultura - 1].lucratividade * vetAreaLotes[i];

                        // Somando a Lucratividade:
                        lt += vetCulturas[cultura - 1].lucratividade * vetAreaLotes[i];

                        // Somando a Funcao Objetivo:
                        solucao.funcObj += vetCulturas[cultura - 1].lucratividade * vetAreaLotes[i];
                    }
                }
            }
        }
    }

    int pousios = 0;

    for (int i = 0; i < quantidadeLotes; i++)
    {
        if (vetPousioLote[i] == 0)
        {
            pousios++;
        }
    }


    // Aplicando as Penalizações na FO:
    solucao.funcObj -= OM1 * MAX(0, cf);      // Cultura Fora de Época ou Ciclo;
    solucao.funcObj -= OM2 * MAX(0, cc);      // Mesma Cultura plantada em sequencia no mesmo lote;
    solucao.funcObj -= OM3 * MAX(0, pa);      // Mesma Familia em mesmo periodo em lotes adjacentes
    solucao.funcObj -= OM4 * MAX(0, av);      // Total de Adubação Verde por Rotação
    solucao.funcObj -= OM5 * MAX(0, pousios); // Total de Falta de pousios por lote;
}
